<?php
$key = "TRIAL";

$addr = array(
			"recommendationFlow" => true,
			"lastName"			 => "",
			"firstName"			 => "",
			"addressLine1"		 => "",
			"addressLine2"		 => "",
			"stateOrProvince"	 => "",
			"city"				 => "",
			"postalCode"		 => "",
			"country"			 => "",
			"phoneCountryCode"	 => "",
			"phoneNumber"		 => "",
			"email"				 => "",
			"emailConfirm"		 => "",
			"makePrimary"		 => false,
			"disableValidation"	 => false,
			"pageType"			 => "ryp"
		);
